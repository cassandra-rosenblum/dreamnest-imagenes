# MÓDULO AUTORRELLENADO DE FORMULARIOS BANCARIOS — DREAM NEST
## Paquete completo para trabajar en otro chat

Objetivo: que el CRM (Apps Script + Vercel) genere los formularios de banco
PRERRELLENADOS con los datos de la operación y los adjunte al email de comunicaciones.

Reto técnico: el relleno se construyó aquí con Python/pypdf, pero el CRM en
producción NO ejecuta Python (solo JavaScript). La solución es rehacer el
relleno con **pdf-lib** (JS) en el navegador del CRM, alojando las plantillas
rellenables en un sitio accesible (GitHub recomendado, como las imágenes).

El RESULTADO debe salir IDÉNTICO al validado aquí con pypdf.

═══════════════════════════════════════════════════════════════
ESTADO DE CADA BANCO
═══════════════════════════════════════════════════════════════

| Banco | Documentos del paquete | Por solicitante | Plantilla lista |
|-------|------------------------|-----------------|-----------------|
| CaixaBank | MAF (conjunto) + Anexo 2 | MAF: 1 · Anexo 2: uno por titular | Anexo 2 ✅ · MAF: falta remapear |
| ABANCA | Solicitud Riesgos/CIRBE | 1 (caben 3 titulares dentro) | ✅ |
| Sabadell | Cesión datos ES + EN | uno por titular | ✅ ES y EN |

RECOMENDACIÓN: empezar por Sabadell (8 campos) para validar el patrón pdf-lib
de punta a punta, luego ABANCA (20), y el MAF (218) el último.

═══════════════════════════════════════════════════════════════
ARCHIVOS EN ESTE PAQUETE
═══════════════════════════════════════════════════════════════

/plantillas/   → PDF rellenables (vacíos) listos para subir a GitHub
  - Sabadell_ES_RELLENABLE.pdf   (2 págs, 8 campos, agente ya puesto)
  - Sabadell_EN_RELLENABLE.pdf   (2 págs, 8 campos, agente "Dream Nest Consultants S.L." ya puesto)
  - ABANCA_RELLENABLE.pdf        (1 pág, 20 campos, EUR + colaborador ya puestos)
  - CaixaBank_Anexo2_RELLENABLE.pdf (1 pág, 2 campos, nombre legal + CIF ya puesto)

/originales/   → los PDF originales (por si hay que regenerar plantillas)
  - Solicitud_Riesgos_ABANCA_LOPD_.pdf
  - Autoriz__datos__anexo_III__castellano.pdf
  - Autoriz__datos__anexo_III__Inglés.pdf
  - (MAF: NO incluido por tamaño 12MB; está en uploads como
     MAF_ingles_pdf_editable__007_.pdf — re-subir en el otro chat)

═══════════════════════════════════════════════════════════════
MAPEOS — campo del PDF → dato del CRM
═══════════════════════════════════════════════════════════════
Notas de campos del CRM (claves tal como están en la operación):
- applicant1.firstName / applicant1.lastName → nombre / apellidos titular 1
- applicant1.dniNieNumber / applicant1.passportNumber → documento
- applicant1.addressStreet → domicilio
- contact.phoneCode + contact.phone (o applicant1.phone) → teléfono
- contact.email (o applicant1.email) → email
- applicant1.dob → fecha nacimiento (¡formato DD/MM/AAAA! usar iaDatePretty_)
- applicant1.nationality, applicant1.countryResidence
- (idem applicant2.*, applicant3.* para 2º y 3º titular)
- leadId → referencia de la operación

Coordenadas PDF: origen ABAJO-IZQUIERDA. Si una etiqueta está a "top" px
desde arriba en una página A4 (alto 842), entonces y = 842 - top - alto_campo.

───────────────────────────────────────────────────────────────
SABADELL — Cesión de datos (ES y EN) — UNO POR SOLICITANTE
───────────────────────────────────────────────────────────────
Plantilla de 2 páginas. 8 campos de texto. El agente ya viene escrito.
Campos (nombre interno → dato):

ES:
  apellidos_nombre  → "{apellidos}, {nombre}"  (o nombre completo)
  nif_residencia    → applicant.dniNieNumber (NIF país residencia)
  pasaporte         → applicant.passportNumber
  fecha_nacimiento  → applicant.dob (DD/MM/AAAA)
  email             → contact.email
  telefono_movil    → contact.phoneCode + phone
  lugar             → (a mano / provincia)
  fecha_firma       → (en blanco, a mano al firmar)

EN (mismos datos, nombres de campo distintos):
  surname_firstname → "{apellidos}, {nombre}"
  tax_id_residence  → dniNieNumber
  passport          → passportNumber
  date_of_birth     → dob
  email             → email
  mobile_phone      → phone
  place             → (a mano)
  date_sign         → (en blanco)

Coordenadas usadas al CREAR los campos (sobre el PDF original de 2 págs):
ES: apellidos_nombre(205,108) nif_residencia(300,121) pasaporte(270,134)
    fecha_nacimiento(180,147) email(169,160) telefono_movil(153,173)
    lugar(pág2: 115,370) fecha_firma(pág2: 117,393)
EN: surname_firstname(215,108) tax_id_residence(270,121) passport(247,134)
    date_of_birth(145,147) email(151,160) mobile_phone(185,173)
    place(pág2: 115,242) date_sign(pág2: 112,265)
(formato: x, top. Ancho ~ 185-360, alto ~ 11-13)

EN: el placeholder "[name of the agent]" (x172-259, top196) se tapó con
rectángulo blanco y se escribió "Dream Nest Consultants S.L." a 6.5pt.
En las plantillas ya entregadas eso YA ESTÁ HECHO.

───────────────────────────────────────────────────────────────
ABANCA — Solicitud de Riesgos / CIRBE — 1 FORMULARIO (hasta 3 titulares)
───────────────────────────────────────────────────────────────
Plantilla de 1 página, 20 campos AcroForm nativos. Todos en página 1.

  plain_input_01  → FECHA            (en blanco, a mano)
  _#1             → TIPO SOLICITUD   (DESPLEGABLE; fijar "PRÉSTAMO HIPOTECARIO ABANCA")
  plain_input_03  → MONEDA           (EUR, fijo)
  plain_input_04  → Nº OPERACIÓN     (leadId del CRM, ej OP-2026-xxx)
  plain_input_05  → COLABORADOR      ("DREAM NEST CONSULTANTS S.L.", fijo)
  -- Titular 1 --
  plain_input_06  → nombre + apellidos
  plain_input_07  → domicilio
  plain_input_08  → doc identificación (DNI/NIE o pasaporte)
  plain_input_09  → teléfono
  plain_input_10  → email
  -- Titular 2 --  plain_input_11..15  (mismos campos)
  -- Titular 3 --  plain_input_16..20  (mismos campos)

OJO con el desplegable _#1: es un campo /Ch con /Opt:
  [['value','PRÉSTAMO PERSONAL ABANCA'], ['value','PRÉSTAMO HIPOTECARIO ABANCA']]
En pypdf hubo que fijar /V = "PRÉSTAMO HIPOTECARIO ABANCA" Y generar una
apariencia (/AP) explícita para que se viera en todos los visores.
En pdf-lib: usar form.getDropdown('_#1').select('PRÉSTAMO HIPOTECARIO ABANCA')
y luego .enableReadOnly() o dejar editable; verificar que se ve el texto.

───────────────────────────────────────────────────────────────
CAIXABANK ANEXO 2 — UNO POR SOLICITANTE
───────────────────────────────────────────────────────────────
Plantilla 1 página, 2 campos. Nombre legal + CIF ya escritos en el texto
("Dream Nest Consultants S.L., CIF B19728146, ...").

  full_name    → nombre completo del solicitante
  national_id  → DNI/NIE o pasaporte del solicitante

Coordenadas al crear (sobre PDF original): full_name(235,489) national_id(285,512)
(x, top; ancho 185, alto 12; fuente Helvetica 10)

───────────────────────────────────────────────────────────────
CAIXABANK MAF — 218 campos — PENDIENTE DE REMAPEAR
───────────────────────────────────────────────────────────────
El MAF original (MAF_ingles_pdf_editable__007_.pdf, 12MB) es rellenable
nativo, 218 campos AcroForm. El mapeo de los 218 campos se hizo en un CHAT
ANTERIOR y NO está en este paquete.
ACCIÓN en el otro chat: re-subir el MAF e inspeccionar sus campos
(r.get_fields()) para reconstruir el mapeo, o recuperar el mapeo del chat
anterior si se guardó.
El agente aparece en pág 6 con "DREAM NEST CONSULTANTS S.L." y el CIF ya
está en el MAF (confirmado por Cassandra).
Paquete CaixaBank final = 1 MAF (conjunto, firmado por todos) + N Anexos 2
(uno por titular). Documentos SEPARADOS.

═══════════════════════════════════════════════════════════════
LÓGICA "UNO POR SOLICITANTE"
═══════════════════════════════════════════════════════════════
El motor debe leer cuántos solicitantes tiene la operación (applicant1,
applicant2, applicant3...) y generar:
- Sabadell Anexo III: una copia por cada titular
- CaixaBank Anexo 2: una copia por cada titular
- CaixaBank MAF: UNA sola (conjunta)
- ABANCA: UNA sola (los 3 titulares caben en la misma hoja)

═══════════════════════════════════════════════════════════════
PLAN SUGERIDO EN EL OTRO CHAT
═══════════════════════════════════════════════════════════════
1. Subir las plantillas de /plantillas/ a GitHub (carpeta tipo PLANTILLAS).
2. Traducir el mapeo de SABADELL a pdf-lib; generar PDF y comparar que sale
   IDÉNTICO al de pypdf (verificar posiciones, agente, 2 páginas).
3. Conectar al botón "Enviar comunicación" del CRM (módulo Comunicaciones
   fase 2b): el navegador rellena con pdf-lib y manda el PDF en base64 al
   backend; MailApp lo adjunta.
4. Repetir con ABANCA (cuidado con el desplegable) y Anexo 2.
5. Remapear el MAF (218 campos) y añadirlo.
6. Implementar "uno por solicitante".

CONTEXTO DEL ENVÍO (ya hecho en este chat, fase 2a):
- Acción backend 'send_comm' en core.gs + sendCommEmail_ en emails.gs YA
  EXISTEN y envían el email (sin adjuntos todavía).
- El email sale con nombre de la asesora logueada + su email como replyTo.
- Falta SOLO adjuntar los PDF (esta fase 2b).

DEPENDENCIA CRÍTICA: el relleno tira de los datos de la operación
(applicant1.*, etc.). Si la IA "Clara" no vuelca bien esos campos en
Solicitantes, los formularios saldrán vacíos aunque el motor funcione.
Verificar el volcado antes de dar por bueno el autorrelleno.

REGLAS DE NEGOCIO:
- Fecha nacimiento SIEMPRE DD/MM/AAAA (nunca con hora). Usar iaDatePretty_.
- Agente = "Dream Nest Consultants S.L." (con CIF B19728146 donde aplique).
- Todos los campos deben quedar EDITABLES tras el relleno.

# SCRIPTS PYTHON DE REFERENCIA (validados en este chat)
# Sirven como ESPECIFICACIÓN para traducir el relleno a pdf-lib (JavaScript).
# La lógica es idéntica; solo cambia el lenguaje.

# ════════════════════════════════════════════════════════
# SABADELL — rellenar (sobre Sabadell_ES_RELLENABLE.pdf / _EN_)
# ════════════════════════════════════════════════════════
from pypdf import PdfReader, PdfWriter

def fill_sabadell_ES(template, out, datos):
    # datos = {apellidos_nombre, nif_residencia, pasaporte, fecha_nacimiento,
    #          email, telefono_movil, lugar, fecha_firma}
    r = PdfReader(template); w = PdfWriter(); w.append(r)
    for pg in w.pages:
        try: w.update_page_form_field_values(pg, datos, auto_regenerate=False)
        except: pass
    with open(out, 'wb') as f: w.write(f)

def fill_sabadell_EN(template, out, datos):
    # datos = {surname_firstname, tax_id_residence, passport, date_of_birth,
    #          email, mobile_phone, place, date_sign}
    r = PdfReader(template); w = PdfWriter(); w.append(r)
    for pg in w.pages:
        try: w.update_page_form_field_values(pg, datos, auto_regenerate=False)
        except: pass
    with open(out, 'wb') as f: w.write(f)

# Ejemplo de datos (lead Brookes):
# ES: {'apellidos_nombre':'Brookes, Philip','nif_residencia':'X1234567Z',
#      'pasaporte':'GBR123456789','fecha_nacimiento':'12/03/1980',
#      'email':'philip.brookes@email.com','telefono_movil':'+44 7700 900123',
#      'lugar':'Valencia','fecha_firma':'09/06/2026'}


# ════════════════════════════════════════════════════════
# ABANCA — rellenar (sobre ABANCA_RELLENABLE.pdf)
# OJO: el desplegable _#1 necesita apariencia explícita
# ════════════════════════════════════════════════════════
from pypdf.generic import (NameObject, TextStringObject, BooleanObject,
                           DictionaryObject, ArrayObject, NumberObject,
                           DecodedStreamObject)

def fill_abanca(template, out, solicitantes, num_operacion='', fecha=''):
    # solicitantes = lista de hasta 3 dicts:
    #   {nombre, apellidos, domicilio, doc, telefono, email}
    r = PdfReader(template); w = PdfWriter(); w.append(r)
    def sol(i, c): return solicitantes[i].get(c, '') if i < len(solicitantes) else ''
    valores = {
        'plain_input_01': fecha,
        'plain_input_03': 'EUR',
        'plain_input_04': num_operacion,                 # leadId
        'plain_input_05': 'DREAM NEST CONSULTANTS S.L.',
        'plain_input_06': (sol(0,'nombre')+' '+sol(0,'apellidos')).strip(),
        'plain_input_07': sol(0,'domicilio'),
        'plain_input_08': sol(0,'doc'),
        'plain_input_09': sol(0,'telefono'),
        'plain_input_10': sol(0,'email'),
        'plain_input_11': (sol(1,'nombre')+' '+sol(1,'apellidos')).strip(),
        'plain_input_12': sol(1,'domicilio'),
        'plain_input_13': sol(1,'doc'),
        'plain_input_14': sol(1,'telefono'),
        'plain_input_15': sol(1,'email'),
        'plain_input_16': (sol(2,'nombre')+' '+sol(2,'apellidos')).strip(),
        'plain_input_17': sol(2,'domicilio'),
        'plain_input_18': sol(2,'doc'),
        'plain_input_19': sol(2,'telefono'),
        'plain_input_20': sol(2,'email'),
    }
    for pg in w.pages:
        try: w.update_page_form_field_values(pg, valores, auto_regenerate=False)
        except: pass
    # Desplegable _#1 → "PRÉSTAMO HIPOTECARIO ABANCA" con apariencia explícita
    TIPO = 'PRÉSTAMO HIPOTECARIO ABANCA'
    for pg in w.pages:
        for a in (pg.get('/Annots') or []):
            o = a.get_object()
            name = o.get('/T') or (o.get('/Parent').get_object().get('/T') if o.get('/Parent') else None)
            if str(name) == '_#1':
                rect = o.get('/Rect')
                wd = float(rect[2]) - float(rect[0]); ht = float(rect[3]) - float(rect[1])
                o[NameObject('/V')] = TextStringObject(TIPO)
                esc = TIPO.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
                stream = ("/Tx BMC\nq\nBT\n/Helv 7 Tf 0 g\n2 %.2f Td\n(%s) Tj\nET\nQ\nEMC" % (ht/2-3, esc))
                ap = DecodedStreamObject(); ap.set_data(stream.encode('latin-1','replace'))
                ap[NameObject('/Type')] = NameObject('/XObject')
                ap[NameObject('/Subtype')] = NameObject('/Form')
                ap[NameObject('/BBox')] = ArrayObject([NumberObject(0),NumberObject(0),NumberObject(wd),NumberObject(ht)])
                helv = DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica'),NameObject('/Encoding'):NameObject('/WinAnsiEncoding')})
                fontd = DictionaryObject({NameObject('/Helv'):w._add_object(helv)})
                ap[NameObject('/Resources')] = DictionaryObject({NameObject('/Font'):fontd})
                o[NameObject('/AP')] = DictionaryObject({NameObject('/N'):w._add_object(ap)})
    try: w._root_object['/AcroForm'][NameObject('/NeedAppearances')] = BooleanObject(True)
    except: pass
    with open(out, 'wb') as f: w.write(f)

# En pdf-lib (JS) el desplegable es más simple:
#   const dd = form.getDropdown('_#1'); dd.select('PRÉSTAMO HIPOTECARIO ABANCA');
#   form.updateFieldAppearances();   // y verificar que se ve


# ════════════════════════════════════════════════════════
# CAIXABANK ANEXO 2 — rellenar (uno por solicitante)
# ════════════════════════════════════════════════════════
def fill_anexo2(template, out, nombre_completo, doc_id):
    r = PdfReader(template); w = PdfWriter(); w.append(r)
    w.update_page_form_field_values(w.pages[0],
        {'full_name': nombre_completo, 'national_id': doc_id},
        auto_regenerate=False)
    with open(out, 'wb') as f: w.write(f)


# ════════════════════════════════════════════════════════
# EQUIVALENTE EN PDF-LIB (esquema general a seguir en el navegador)
# ════════════════════════════════════════════════════════
# import { PDFDocument } from 'pdf-lib';
# const bytes = await fetch(URL_PLANTILLA).then(r => r.arrayBuffer());
# const pdf = await PDFDocument.load(bytes);
# const form = pdf.getForm();
# form.getTextField('apellidos_nombre').setText('Brookes, Philip');
# // ... resto de campos ...
# form.getDropdown('_#1').select('PRÉSTAMO HIPOTECARIO ABANCA'); // ABANCA
# // dejar editable (NO flatten) para que el asesor pueda corregir
# const out = await pdf.save();   // Uint8Array → base64 → backend → MailApp
